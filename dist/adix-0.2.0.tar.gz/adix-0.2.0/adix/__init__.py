from .processing import wiz,calc,eda
from .configs import *


__version__ = "0.2.0"
__license__ = "MIT License"
