from .processing import wiz,calc,eda
from .configs import *


__version__ = 1.0.0
